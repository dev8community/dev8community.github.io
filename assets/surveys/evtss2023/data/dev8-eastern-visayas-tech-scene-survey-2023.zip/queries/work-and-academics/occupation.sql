-- All occupation options have been selected.
SELECT occupation, COUNT(occupation)
FROM participant
GROUP BY occupation
ORDER BY COUNT(occupation) DESC, occupation ASC;