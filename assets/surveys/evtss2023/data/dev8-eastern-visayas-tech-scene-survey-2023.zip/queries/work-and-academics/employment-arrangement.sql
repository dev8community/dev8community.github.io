WITH arrangements AS
(
	SELECT DISTINCT employment.employment_arrangement AS 'arrangement'
	FROM employment
	UNION SELECT ALL 'Hybrid Remote (mostly in-office, fixed time)'
), participant_arrangements AS
(
    SELECT participant.id, employment.employment_arrangement AS 'arrangement'
	FROM participant
	INNER JOIN employment ON participant.id = employment.participant_id
)
SELECT arrangements.arrangement, COUNT(participant_arrangements.id)
FROM arrangements
LEFT JOIN participant_arrangements ON participant_arrangements.arrangement = arrangements.arrangement
GROUP BY arrangements.arrangement
ORDER BY COUNT(participant_arrangements.id) DESC, arrangements.arrangement ASC;