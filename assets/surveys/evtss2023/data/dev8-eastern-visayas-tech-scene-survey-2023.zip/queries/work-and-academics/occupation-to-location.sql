WITH occupations AS
(
	SELECT DISTINCT occupation
	FROM participant
)
SELECT occupations.occupation, COUNT(participant.id)
FROM occupations
LEFT JOIN participant ON occupations.occupation = participant.occupation
                     AND participant.location = 'Province of Biliran'
GROUP BY occupations.occupation
ORDER BY occupations.occupation ASC;