-- All options have been selected so no need to do JOINs for 0 values.
SELECT annual_income_satisfaction, COUNT(annual_income_satisfaction)
FROM employment
GROUP BY annual_income_satisfaction
ORDER BY COUNT(annual_income_satisfaction) DESC, annual_income_satisfaction ASC;
