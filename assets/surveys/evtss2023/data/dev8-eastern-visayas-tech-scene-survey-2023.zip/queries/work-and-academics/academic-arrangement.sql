WITH arrangements AS
(
	SELECT DISTINCT academics.academic_arrangement
	FROM academics
	UNION ALL SELECT 'I am not enrolled'
	UNION ALL SELECT 'Online'
), participant_arrangements AS
(
	SELECT participant.id, academics.academic_arrangement
	FROM participant
	INNER JOIN academics ON participant.id = academics.participant_id
)
SELECT arrangements.academic_arrangement, COUNT(participant_arrangements.id)
FROM arrangements
LEFT JOIN participant_arrangements ON participant_arrangements.academic_arrangement = arrangements.academic_arrangement
GROUP BY arrangements.academic_arrangement
ORDER BY COUNT(participant_arrangements.id) DESC, arrangements.academic_arrangement ASC;
