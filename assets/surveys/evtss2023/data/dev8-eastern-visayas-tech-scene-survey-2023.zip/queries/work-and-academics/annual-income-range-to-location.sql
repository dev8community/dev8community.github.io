WITH income_ranges AS
(
	SELECT DISTINCT annual_income_range AS range
	FROM employment
	UNION ALL SELECT 'PHP 10,000,001 or higher'
	UNION ALL SELECT 'PHP 2,500,001 - PHP 5,000,000'
	UNION ALL SELECT 'PHP 8,000,001 - PHP 10,000,000'
), participant_incomes AS
(
	SELECT participant.id, participant.location, employment.annual_income_range
	FROM participant
	INNER JOIN employment ON participant.id = employment.participant_id
)

SELECT income_ranges.range, COUNT(participant_incomes.id)
FROM income_ranges
LEFT JOIN participant_incomes ON participant_incomes.annual_income_range = income_ranges.range
							 AND participant_incomes.location = 'Province of Biliran'
GROUP BY income_ranges.range
ORDER BY income_ranges.range ASC;