WITH locations AS
(
	SELECT DISTINCT employer_location AS 'location'
	FROM employment
	UNION ALL SELECT 'Catarman, Northern Samar'
	UNION ALL SELECT 'Maasin City'
	UNION ALL SELECT 'Palo, Leyte'
), participants_employment AS
(
    SELECT participant.id, employment.employer_location AS 'location'
	FROM participant
	INNER JOIN employment ON participant.id = employment.participant_id
)
SELECT locations.location, COUNT(participants_employment.id)
FROM locations
LEFT JOIN participants_employment ON participants_employment.location = locations.location
GROUP BY locations.location
ORDER BY COUNT(participants_employment.id) DESC, locations.location ASC;
