WITH satisfactions AS
(
	SELECT DISTINCT annual_income_satisfaction AS 'satisfaction'
	FROM employment
), participant_incomes AS
(
	SELECT participant.id, participant.location, employment.annual_income_satisfaction AS 'satisfaction'
	FROM participant
	INNER JOIN employment ON participant.id = employment.participant_id
)

SELECT satisfactions.satisfaction, COUNT(participant_incomes.id)
FROM satisfactions
LEFT JOIN participant_incomes ON participant_incomes.satisfaction = satisfactions.satisfaction
							 AND participant_incomes.location = 'Province of Biliran'
GROUP BY satisfactions.satisfaction
ORDER BY satisfactions.satisfaction ASC;