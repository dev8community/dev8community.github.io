WITH locations AS
(
	SELECT DISTINCT employer_location AS 'location'
	FROM employment
	UNION ALL SELECT 'Catarman, Northern Samar'
	UNION ALL SELECT 'Maasin City'
	UNION ALL SELECT 'Palo, Leyte'
), participants_employment AS
(
    SELECT participant.id, participant.location, employment.employer_location AS 'emp_location'
	FROM participant
	INNER JOIN employment ON participant.id = employment.participant_id
)
SELECT locations.location, COUNT(participants_employment.id)
FROM locations
LEFT JOIN participants_employment ON participants_employment.emp_location = locations.location
                                 AND participants_employment.location = 'Province of Biliran'
GROUP BY locations.location
ORDER BY locations.location ASC;
