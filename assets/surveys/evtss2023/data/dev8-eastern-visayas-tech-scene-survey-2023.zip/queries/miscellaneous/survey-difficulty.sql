SELECT survey_difficulty, COUNT(id)
FROM participant
GROUP BY survey_difficulty
ORDER BY COUNT(id) DESC, survey_difficulty ASC;