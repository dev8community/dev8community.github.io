SELECT is_survey_length_okay, COUNT(id)
FROM participant
GROUP BY is_survey_length_okay
UNION ALL SELECT 'Too short', 0
ORDER BY COUNT(id) DESC, is_survey_length_okay ASC;