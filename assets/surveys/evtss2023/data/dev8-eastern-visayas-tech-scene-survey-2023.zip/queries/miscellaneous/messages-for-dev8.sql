SELECT TRIM(message_for_dev8)
FROM participant
WHERE TRIM(message_for_dev8) <> '' AND TRIM(message_for_dev8) <> '.'
ORDER BY TRIM(message_for_dev8) ASC;