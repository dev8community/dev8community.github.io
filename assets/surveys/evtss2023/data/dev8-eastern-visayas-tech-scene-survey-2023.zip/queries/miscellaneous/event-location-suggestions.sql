SELECT DISTINCT TRIM(event_location_suggestions)
FROM participant
WHERE TRIM(event_location_suggestions) <> '' AND TRIM(event_location_suggestions) <> ' '
ORDER BY TRIM(event_location_suggestions) ASC;