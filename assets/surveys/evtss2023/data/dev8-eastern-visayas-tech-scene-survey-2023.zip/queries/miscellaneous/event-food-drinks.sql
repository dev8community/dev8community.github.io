SELECT suggestion, COUNT(participant_id)
FROM tech_event_food_or_drink
GROUP BY suggestion
ORDER BY COUNT(participant_id) DESC, suggestion ASC;