WITH degrees AS
(
	SELECT DISTINCT degree
	FROM higher_academics
	UNION ALL SELECT 'Applied Mathematics'
	UNION ALL SELECT 'Applied Physics'
	UNION ALL SELECT 'Electrical Engineering'
	UNION ALL SELECT 'Information Systems'
	UNION ALL SELECT 'Mathematics'
	UNION ALL SELECT 'Physics'
	UNION ALL SELECT 'Software Engineering'
), participants_degree AS
(
	SELECT participant.id, higher_academics.degree
	FROM participant
	INNER JOIN higher_academics ON participant.id = higher_academics.participant_id
)
SELECT degrees.degree, COUNT(participants_degree.id)
FROM degrees
LEFT JOIN participants_degree ON degrees.degree = participants_degree.degree
GROUP BY degrees.degree
ORDER BY COUNT(participants_degree.id) DESC, degrees.degree ASC;