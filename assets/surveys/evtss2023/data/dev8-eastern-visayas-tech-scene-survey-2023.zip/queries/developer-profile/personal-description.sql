SELECT personal_description, COUNT(personal_description)
FROM participant
GROUP BY personal_description
ORDER BY COUNT(personal_description) DESC, personal_description ASC;
