SELECT model, COUNT(model)
FROM mobile;