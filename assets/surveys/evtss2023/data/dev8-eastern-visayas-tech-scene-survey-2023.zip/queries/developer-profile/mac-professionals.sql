WITH macs AS
(
    SELECT DISTINCT mac.model
	FROM mac
	UNION ALL SELECT 'iMac (Intel CPUs)'
	UNION ALL SELECT 'Mac mini (M-series CPUs)'
	UNION ALL SELECT 'Mac mini (Intel CPUs)'
	UNION ALL SELECT 'Mac Studio'
	UNION ALL SELECT 'Mac Pro (M-series CPUs)'
	UNION ALL SELECT 'Mac Pro (Intel CPUs)'
	UNION ALL SELECT 'MacBook'
	UNION ALL SELECT 'Other Mac models'
	UNION ALL SELECT 'Basta Mac 😅/I do not know'
), participant_models AS (
    SELECT participant.id, participant.occupation, mac.model
	FROM mac
	INNER JOIN participant ON participant.id = mac.participant_id
)
SELECT macs.model, COUNT(participant_models.id)
FROM macs
LEFT JOIN participant_models ON participant_models.model = macs.model
                            AND participant_models.occupation = 'Professional/Freelancer'
GROUP BY macs.model
ORDER BY COUNT(participant_models.id) DESC, macs.model ASC;
