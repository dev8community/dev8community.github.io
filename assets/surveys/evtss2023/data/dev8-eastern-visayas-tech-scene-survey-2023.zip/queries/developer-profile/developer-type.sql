WITH developer_types AS
(
	SELECT DISTINCT participant.developer_type
	FROM participant
	UNION ALL SELECT 'Blockchain Developer'
	UNION ALL SELECT 'Database Administrator'
	UNION ALL SELECT 'Designer'
	UNION ALL SELECT 'Developer Advocate'
	UNION ALL SELECT 'Engineering Manager'
	UNION ALL SELECT 'Graphics Developer'
	UNION ALL SELECT 'Hardware Engineer'
	UNION ALL SELECT 'Mobile Developer'
	UNION ALL SELECT 'Product Manager'
	UNION ALL SELECT 'Project Manager'
	UNION ALL SELECT 'Quantum Computing/Advanced Science Technology Researcher'
	UNION ALL SELECT 'Scientist'
	UNION ALL SELECT 'Security Professional'
	UNION ALL SELECT 'Senior Executive (C-Suite, VP, etc.)'
	UNION ALL SELECT 'Site Reliability Engineer'
	UNION ALL SELECT 'System Administrator'
)
	
SELECT developer_types.developer_type, COUNT(participant.developer_type)
FROM developer_types
LEFT JOIN participant ON developer_types.developer_type = participant.developer_type
GROUP BY developer_types.developer_type
ORDER BY COUNT(participant.developer_type) DESC, developer_types.developer_type ASC;