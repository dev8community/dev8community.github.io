WITH locations AS (
    SELECT DISTINCT participant.location
	FROM participant
	UNION ALL SELECT 'Catarman, Northern Samar'
	UNION ALL SELECT 'Maasin City'
	UNION ALL SELECT 'Province of Northern Samar'
	UNION ALL SELECT 'Province of Southern Leyte'
)
SELECT locations.location, COUNT(participant.id)
FROM locations
LEFT JOIN participant ON participant.location = locations.location
GROUP BY locations.location
ORDER BY COUNT(participant.id) DESC, locations.location ASC;
