WITH ages AS
(
	SELECT DISTINCT age
	FROM participant
	UNION ALL SELECT '55 - 64 years old'
	UNION ALL SELECT '65 years or older'
	UNION ALL SELECT 'Under 18 years old'
)
SELECT ages.age, COUNT(participant.id)
FROM ages
LEFT JOIN participant ON participant.age = ages.age
GROUP BY ages.age
ORDER BY COUNT(participant.id) DESC, ages.age;