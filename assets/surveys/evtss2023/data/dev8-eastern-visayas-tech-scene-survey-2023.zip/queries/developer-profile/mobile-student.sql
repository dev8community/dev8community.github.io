SELECT model, COUNT(model)
FROM mobile
INNER JOIN participant ON participant.id = mobile.participant_id
WHERE participant.occupation = 'Student' OR participant.occupation = 'Unemployed';