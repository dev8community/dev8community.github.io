WITH exp_lengths AS (
	SELECT DISTINCT participant.prof_programming_exp_length  AS 'exp_length'
	FROM participant
	UNION ALL SELECT '15 - 19 years'
	UNION ALL SELECT '30 - 34 years'
	UNION ALL SELECT '35 - 39 years'
	UNION ALL SELECT '40 - 44 years'
	UNION ALL SELECT '45 - 49 years'
	UNION ALL SELECT '50 years or more'
)
SELECT exp_lengths.exp_length, COUNT(participant.prof_programming_exp_length)
FROM exp_lengths
LEFT JOIN participant ON exp_lengths.exp_length = participant.prof_programming_exp_length
GROUP BY exp_lengths.exp_length
ORDER BY COUNT(participant.prof_programming_exp_length) DESC, exp_lengths.exp_length ASC;