WITH hometowns AS
(
    SELECT DISTINCT hometown
    FROM participant
	UNION ALL SELECT 'Bangsamoro (BARMM)'
	UNION ALL SELECT 'Bicol Region (Region V)'
	UNION ALL SELECT 'Cagayan Valley (Region II)'
	UNION ALL SELECT 'CALABARZON (Region IV-A)'
	UNION ALL SELECT 'Caraga (Region XIII)'
	UNION ALL SELECT 'Catarman, Northern Samar'
	UNION ALL SELECT 'Central Luzon (Region III)'
	UNION ALL SELECT 'Cordillera Administrative Region (CAR)'
	UNION ALL SELECT 'Davao Region (Region XI)'
	UNION ALL SELECT 'Ilocos Region (Region I)'
	UNION ALL SELECT 'Maasin City'
	UNION ALL SELECT 'MIMAROPA (Region IV-B)'
	UNION ALL SELECT 'Northern Mindanao (Region X)'
	UNION ALL SELECT 'Province of Northern Samar'
	UNION ALL SELECT 'SOCCSKSARGEN (Region XII)'
	UNION ALL SELECT 'Western Visayas (Region VI)'
	UNION ALL SELECT 'Zamboanga Peninsula (Region IX)'
)
SELECT hometowns.hometown, COUNT(participant.id)
FROM hometowns
LEFT JOIN participant ON participant.hometown = hometowns.hometown
                     AND participant.location = 'Province of Biliran'
GROUP BY hometowns.hometown
ORDER BY hometowns.hometown ASC;