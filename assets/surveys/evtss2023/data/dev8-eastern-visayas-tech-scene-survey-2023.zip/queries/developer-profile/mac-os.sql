SELECT os, COUNT(os)
FROM mac
INNER JOIN participant ON participant.id = mac.participant_id
GROUP BY os
ORDER BY COUNT(os) DESC, os ASC;
