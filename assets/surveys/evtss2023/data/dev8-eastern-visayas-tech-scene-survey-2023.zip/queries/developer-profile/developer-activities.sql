-- All of the activity categories (disregarding the 'None' option) have been selected
-- so need to look for categories with zero selection.
SELECT activity, COUNT(activity)
FROM developer_activity
GROUP BY activity
ORDER BY COUNT(activity) DESC, activity ASC;