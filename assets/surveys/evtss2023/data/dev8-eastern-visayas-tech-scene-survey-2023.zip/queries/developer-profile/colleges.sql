WITH colleges AS
(
	SELECT DISTINCT college_alma_mater AS 'college'
	FROM higher_academics
	UNION ALL SELECT 'Biliran Province State University'
	UNION ALL SELECT 'Southern Leyte State University'
	UNION ALL SELECT 'University of Eastern Philippines'
), participants_college AS
(
	SELECT participant.id, higher_academics.college_alma_mater AS 'college'
	FROM participant
	INNER JOIN higher_academics ON participant.id = higher_academics.participant_id
)
SELECT colleges.college, COUNT(participants_college.id)
FROM colleges
LEFT JOIN participants_college ON colleges.college = participants_college.college
GROUP BY colleges.college
ORDER BY COUNT(participants_college.id) DESC, colleges.college ASC;