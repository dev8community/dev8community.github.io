-- No need for using a temporary table since all specs were selected.
SELECT spec, COUNT(spec
FROM pc_spec
GROUP BY spec
ORDER BY COUNT(spec) DESC, spec ASC;