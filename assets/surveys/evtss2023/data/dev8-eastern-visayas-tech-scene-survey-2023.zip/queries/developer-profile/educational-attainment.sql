WITH attainments AS
(
	SELECT DISTINCT educational_attainment AS 'attainment'
	FROM participant
	UNION ALL SELECT 'Associate Degree (A.A., A.S., etc.)'
	UNION ALL SELECT 'Elementary'
	UNION ALL SELECT 'High School (4-year Curriculum)'
	UNION ALL SELECT 'High School (Junior)'
	UNION ALL SELECT 'Professional Degree (JD, MD, Ph.D, Ed.D, etc.)'
)
SELECT attainments.attainment, COUNT(participant.id)
FROM attainments
LEFT JOIN participant ON participant.educational_attainment = attainments.attainment
GROUP BY attainments.attainment
ORDER BY COUNT(participant.id) DESC, attainments.attainment ASC;