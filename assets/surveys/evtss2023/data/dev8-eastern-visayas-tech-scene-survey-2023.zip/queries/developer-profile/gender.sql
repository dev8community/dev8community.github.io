WITH genders AS
(
	SELECT DISTINCT gender
	FROM participant
	UNION ALL SELECT 'Non-binary, genderqueer, or other gender identities'
)
SELECT genders.gender, COUNT(participant.id)
FROM genders
LEFT JOIN participant ON participant.gender = genders.gender
GROUP BY genders.gender
ORDER BY COUNT(participant.id) DESC, genders.gender ASC;