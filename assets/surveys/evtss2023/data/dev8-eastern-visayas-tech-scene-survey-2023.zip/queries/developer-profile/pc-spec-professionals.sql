WITH pc_specs AS
(
	SELECT DISTINCT spec
	FROM pc_spec
), participant_specs AS
(
    SELECT participant.id, participant.occupation, pc_spec.spec
	FROM participant
	INNER JOIN pc_spec ON participant.id = pc_spec.participant_id
)

SELECT pc_specs.spec, COUNT(participant_specs.id)
FROM pc_specs
LEFT JOIN participant_specs ON participant_specs.spec = pc_specs.spec
                            AND participant_specs.occupation = "Professional/Freelancer"
GROUP BY pc_specs.spec
ORDER BY COUNT(participant_specs.id) DESC, pc_specs.spec ASC;