WITH computers_used AS
(
	SELECT DISTINCT participant.computer_used AS 'computer'
	FROM participant
	UNION ALL SELECT 'A mainframe computer or older'
	UNION ALL SELECT 'Dumbphone (e.g. Nokia 3310)'
	UNION ALL SELECT 'I do not know'
	UNION ALL SELECT 'Raspberry Pi or similar'
	UNION ALL SELECT 'Tablet'
)
SELECT computers_used.computer, COUNT(participant.id)
FROM computers_used
LEFT JOIN participant ON participant.computer_used = computers_used.computer
GROUP BY computers_used.computer
ORDER BY COUNT(participant.id) DESC, computers_used.computer ASC;