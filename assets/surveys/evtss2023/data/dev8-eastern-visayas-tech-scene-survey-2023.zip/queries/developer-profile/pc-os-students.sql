SELECT os, COUNT(os)
FROM pc
INNER JOIN participant ON participant.id = pc.participant_id
WHERE participant.occupation = 'Student' OR participant.occupation = 'Unemployed'
GROUP BY os
ORDER BY COUNT(os) DESC, os ASC;