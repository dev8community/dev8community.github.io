SELECT library, SUM(used), SUM(want_to_use_next_year), SUM(did_not_like_using)
FROM library
INNER JOIN participant ON participant.id = library.participant_id
WHERE participant.occupation = 'Professional/Freelancer'
GROUP BY library
ORDER BY SUM(used) DESC, SUM(want_to_use_next_year) DESC, SUM(did_not_like_using) DESC, library ASC;