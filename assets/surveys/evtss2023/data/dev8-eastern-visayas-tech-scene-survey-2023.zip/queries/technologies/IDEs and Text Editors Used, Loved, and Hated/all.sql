SELECT editor, SUM(used), SUM(want_to_use_next_year), SUM(did_not_like_using)
FROM coding_editor
INNER JOIN participant ON participant.id = coding_editor.participant_id
GROUP BY editor
ORDER BY SUM(used) DESC, SUM(want_to_use_next_year) DESC, SUM(did_not_like_using) DESC, editor ASC;