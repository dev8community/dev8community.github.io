SELECT language, SUM(want_to_use_next_year)
FROM programming_language
GROUP BY language
ORDER BY SUM(want_to_use_next_year) DESC, language ASC;