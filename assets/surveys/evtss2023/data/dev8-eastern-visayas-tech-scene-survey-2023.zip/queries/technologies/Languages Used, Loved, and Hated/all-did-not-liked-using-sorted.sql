SELECT language, SUM(did_not_like_using)
FROM programming_language
GROUP BY language
ORDER BY SUM(did_not_like_using) DESC, language ASC;