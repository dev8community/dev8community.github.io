SELECT database, SUM(used), SUM(want_to_use_next_year), SUM(did_not_like_using)
FROM database
INNER JOIN participant ON participant.id = database.participant_id
WHERE participant.occupation = 'Professional/Freelancer'
GROUP BY database
ORDER BY SUM(used) DESC, SUM(want_to_use_next_year) DESC, SUM(did_not_like_using) DESC, database ASC;