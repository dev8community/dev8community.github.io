SELECT platform, SUM(used), SUM(want_to_use_next_year), SUM(did_not_like_using)
FROM cloud_platform
INNER JOIN participant ON participant.id = cloud_platform.participant_id
WHERE participant.occupation = 'Professional/Freelancer'
GROUP BY platform
ORDER BY SUM(used) DESC, SUM(want_to_use_next_year) DESC, SUM(did_not_like_using) DESC, platform ASC;