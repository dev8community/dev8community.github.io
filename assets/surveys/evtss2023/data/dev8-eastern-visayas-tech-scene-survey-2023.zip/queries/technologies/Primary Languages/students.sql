SELECT language, COUNT(language)
FROM programming_language
INNER JOIN participant ON participant.id = programming_language.participant_id
WHERE is_primary_language = 1 AND participant.occupation = 'Student'
GROUP BY language
ORDER BY COUNT(language) DESC, language ASC;