WITH languages AS
(
	SELECT DISTINCT programming_language.language AS 'language'
	FROM programming_language
), participant_languages AS
(
	SELECT participant.id, participant.location, programming_language.language
	FROM participant
	INNER JOIN programming_language ON participant.id = programming_language.participant_id
	WHERE programming_language.is_primary_language = 1
)
SELECT languages.language, COUNT(participant_languages.id)
FROM languages
LEFT JOIN participant_languages ON participant_languages.langage = languages.language
							   AND participant_languages.location = 'Province of Biliran'
GROUP BY languages.language
ORDER BY languages.language ASC;