SELECT language, COUNT(language)
FROM programming_language
WHERE is_primary_language = 1
GROUP BY language
ORDER BY COUNT(language) DESC, language ASC;