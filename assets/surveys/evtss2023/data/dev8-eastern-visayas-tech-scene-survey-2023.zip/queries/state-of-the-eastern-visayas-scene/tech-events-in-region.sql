SELECT event, COUNT(event)
FROM tech_event_in_region
GROUP BY event
ORDER BY COUNT(event) DESC, event ASC;