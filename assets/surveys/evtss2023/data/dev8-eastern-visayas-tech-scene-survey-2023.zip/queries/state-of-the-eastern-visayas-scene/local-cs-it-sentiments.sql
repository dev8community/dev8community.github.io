SELECT DISTINCT TRIM(local_cs_it_sentiments)
FROM participant
WHERE TRIM(local_cs_it_sentiments) <> ''
	AND TRIM(local_cs_it_sentiments) <> '-'
	AND TRIM(local_cs_it_sentiments) <> ' ' -- I don't know what type of whitespace this is.
ORDER BY TRIM(local_cs_it_sentiments);
