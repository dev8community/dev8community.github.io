SELECT topic, COUNT(topic)
FROM tech_event_topic
GROUP BY topic
ORDER BY COUNT(topic) DESC, topic ASC;