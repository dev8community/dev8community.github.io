WITH platform_category AS
(
    SELECT DISTINCT platform.platform AS 'category'
	FROM platform
), participant_platform_loc AS
(
	SELECT participant.id, participant.location, platform.platform AS 'platform_category'
	FROM platform
	INNER JOIN participant ON participant.id = platform.participant_id
)

SELECT category, COUNT(location)
FROM platform_category
LEFT JOIN participant_platform_loc
	ON platform_category.category = participant_platform_loc.platform_category
		AND participant_platform_loc.location = 'Tacloban City'
GROUP BY category
ORDER BY category ASC;
