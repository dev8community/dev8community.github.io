SELECT platform, COUNT(platform)
FROM platform
INNER JOIN participant ON participant.id = platform.participant_id
GROUP BY platform
ORDER BY COUNT(platform) DESC, platform ASC;