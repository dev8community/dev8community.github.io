WITH platform_category AS
(
    SELECT DISTINCT platform.platform AS 'category'
	FROM platform
), participant_platform_loc_occ AS
(
	SELECT participant.id, participant.location, participant.occupation, platform.platform AS 'platform_category'
	FROM platform
	INNER JOIN participant ON participant.id = platform.participant_id
)

SELECT category, COUNT(location)
FROM platform_category
LEFT JOIN participant_platform_loc_occ
	ON platform_category.category = participant_platform_loc_occ.platform_category
		AND participant_platform_loc_occ.location = 'Province of Biliran'
		AND participant_platform_loc_occ.occupation = 'Professional/Freelancer'
GROUP BY category
ORDER BY category ASC;
