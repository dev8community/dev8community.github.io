WITH software_categories AS
(
    SELECT DISTINCT software.category
	FROM software
	UNION ALL SELECT 'Augmented Reality'
	UNION ALL SELECT 'Virtual Reality'
), participant_software_loc_occ AS
(
	SELECT participant.id, participant.location, participant.occupation, software.category AS 'software_category'
	FROM software
	INNER JOIN participant ON participant.id = software.participant_id
)

SELECT category, COUNT(location)
FROM software_categories
LEFT JOIN participant_software_loc_occ
	ON software_categories.category = participant_software_loc_occ.software_category
		AND participant_software_loc_occ.location = 'Tacloban City'
		AND participant_software_loc_occ.occupation = 'Professional/Freelancer'
GROUP BY category
ORDER BY category ASC;
