SELECT category, COUNT(category)
FROM software
INNER JOIN participant ON participant.id = software.participant_id
WHERE participant.occupation = 'Professional/Freelancer'
GROUP BY category
ORDER BY COUNT(category) DESC, category ASC;