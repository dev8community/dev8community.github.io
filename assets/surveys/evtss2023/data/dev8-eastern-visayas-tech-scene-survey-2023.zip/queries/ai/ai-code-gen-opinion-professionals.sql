SELECT oss_code_ai_training_sentiment, COUNT(id)
FROM participant
WHERE occupation = 'Professional/Freelancer'
GROUP BY oss_code_ai_training_sentiment
UNION ALL SELECT 'Strongly Disagree', 0
ORDER BY COUNT(id) DESC;