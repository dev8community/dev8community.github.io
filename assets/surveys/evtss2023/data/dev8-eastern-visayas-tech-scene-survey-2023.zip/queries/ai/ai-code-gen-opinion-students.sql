SELECT oss_code_ai_training_sentiment, COUNT(id)
FROM participant
WHERE occupation = 'Student' OR occupation = 'Unemployed'
GROUP BY oss_code_ai_training_sentiment
ORDER BY COUNT(id) DESC;