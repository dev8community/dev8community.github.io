-- No need for another temporary table since 
SELECT ai_art_sentiment, COUNT(id)
FROM participant
WHERE occupation = 'Professional/Freelancer'
GROUP BY ai_art_sentiment
ORDER BY COUNT(id) DESC;