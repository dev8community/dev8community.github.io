SELECT COUNT(DISTINCT participant_id)
FROM ai_search_tool
INNER JOIN participant ON participant.id = ai_search_tool.participant_id;