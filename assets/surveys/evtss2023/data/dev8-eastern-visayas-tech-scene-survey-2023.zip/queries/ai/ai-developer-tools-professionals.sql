-- All choices have been selected so no need for unions and temporary tables.
SELECT tool, SUM(used), SUM(want_to_use_next_year), SUM(did_not_like_using)
FROM ai_developer_tool
INNER JOIN participant ON participant.id = ai_developer_tool.participant_id
WHERE participant.occupation = 'Professional/Freelancer'
GROUP BY tool
ORDER BY SUM(used) DESC, SUM(want_to_use_next_year) DESC, SUM(did_not_like_using) DESC, tool ASC;