-- No need for another temporary table since 
SELECT all_data_ai_training_sentiment, COUNT(id)
FROM participant
GROUP BY all_data_ai_training_sentiment
ORDER BY COUNT(id) DESC;